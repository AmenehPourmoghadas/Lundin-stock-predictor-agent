\
from __future__ import annotations
import math
import yfinance as yf

def _clean(value):
    try:
        numeric = float(value)
        return None if math.isnan(numeric) else round(numeric, 4)
    except (TypeError, ValueError):
        return None

def fetch_market_snapshot(tickers: dict[str, str]) -> dict:
    output: dict[str, dict] = {}
    for name, symbol in tickers.items():
        try:
            frame = yf.download(symbol, period="10d", interval="1d", progress=False, auto_adjust=True)
            closes = frame["Close"].dropna()
            if hasattr(closes, "columns"):
                closes = closes.iloc[:, 0]
            latest = _clean(closes.iloc[-1]) if len(closes) else None
            previous = _clean(closes.iloc[-2]) if len(closes) > 1 else None
            change_pct = None
            if latest is not None and previous not in (None, 0):
                change_pct = round((latest / previous - 1) * 100, 3)
            output[name] = {"symbol": symbol, "latest": latest, "previous": previous, "change_pct": change_pct}
        except Exception as exc:
            output[name] = {"symbol": symbol, "error": str(exc)}
    return output
